Training data: clean
Test data: not clean
